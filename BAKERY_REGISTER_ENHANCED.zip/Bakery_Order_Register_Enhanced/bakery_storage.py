"""SQLite persistence layer for the Bakery Order Register.

SQLite gives the project transactional updates, indexed lookups, a write-ahead
log and an audit trail while keeping the app simple to run on a student laptop.
"""
from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from bakery_core import EDITABLE_FIELDS, normalise_order, utc_now, validate_order

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_FILE = DATA_DIR / "bakery_register.db"
LEGACY_JSON_FILE = DATA_DIR / "orders.json"

ORDER_COLUMNS = (
    "order_id", "customer", "phone", "item", "category", "flavour", "quantity",
    "unit_price", "total_amount", "amount_paid", "balance", "pickup_date",
    "pickup_slot", "payment_status", "order_status", "priority", "notes",
    "created_at", "updated_at",
)


class BakeryStore:
    """Small repository that owns all database reads and writes."""

    def __init__(self, db_path: str | Path = DB_FILE, legacy_json_path: str | Path | None = LEGACY_JSON_FILE):
        self.db_path = Path(db_path)
        self.legacy_json_path = Path(legacy_json_path) if legacy_json_path else None
        self._init_lock = threading.Lock()
        self._initialised = False
        self.initialise()

    def _connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(self.db_path, timeout=15, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 15000")
        return connection

    @contextmanager
    def _reader(self):
        connection = self._connect()
        try:
            yield connection
        finally:
            connection.close()

    @contextmanager
    def _transaction(self):
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def initialise(self) -> None:
        with self._init_lock:
            if self._initialised:
                return
            connection = self._connect()
            try:
                connection.execute("PRAGMA journal_mode = WAL")
                connection.executescript(
                    """
                    CREATE TABLE IF NOT EXISTS orders (
                        order_id TEXT PRIMARY KEY,
                        customer TEXT NOT NULL,
                        phone TEXT NOT NULL DEFAULT '',
                        item TEXT NOT NULL,
                        category TEXT NOT NULL DEFAULT 'Cakes',
                        flavour TEXT NOT NULL DEFAULT '',
                        quantity INTEGER NOT NULL CHECK(quantity BETWEEN 1 AND 500),
                        unit_price REAL NOT NULL CHECK(unit_price >= 0),
                        total_amount REAL NOT NULL CHECK(total_amount >= 0),
                        amount_paid REAL NOT NULL CHECK(amount_paid >= 0),
                        balance REAL NOT NULL CHECK(balance >= 0),
                        pickup_date TEXT NOT NULL,
                        pickup_slot TEXT NOT NULL DEFAULT 'Afternoon',
                        payment_status TEXT NOT NULL,
                        order_status TEXT NOT NULL,
                        priority TEXT NOT NULL DEFAULT 'Standard',
                        notes TEXT NOT NULL DEFAULT '',
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    );
                    CREATE INDEX IF NOT EXISTS idx_orders_pickup ON orders(pickup_date, pickup_slot);
                    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(order_status, payment_status);
                    CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer COLLATE NOCASE);
                    CREATE TABLE IF NOT EXISTS audit_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        order_id TEXT NOT NULL,
                        action TEXT NOT NULL,
                        summary TEXT NOT NULL,
                        created_at TEXT NOT NULL
                    );
                    CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at DESC);
                    CREATE TABLE IF NOT EXISTS app_meta (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL
                    );
                    """
                )
                marker = connection.execute("SELECT value FROM app_meta WHERE key='legacy_json_imported'").fetchone()
                if marker is None:
                    self._import_legacy_json(connection)
                    connection.execute(
                        "INSERT OR REPLACE INTO app_meta(key, value) VALUES('legacy_json_imported', '1')"
                    )
                next_number = self._next_order_number(connection)
                self._set_next_order_number(connection, next_number)
                connection.execute("INSERT OR REPLACE INTO app_meta(key, value) VALUES('schema_version', '2')")
            finally:
                connection.close()
            self._initialised = True

    def _import_legacy_json(self, connection: sqlite3.Connection) -> None:
        path = self.legacy_json_path
        if not path or not path.exists():
            return
        try:
            old_records = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(old_records, list):
            return
        for old in old_records:
            if not isinstance(old, dict):
                continue
            payload = {
                "customer": old.get("customer", ""),
                "phone": old.get("phone", ""),
                "item": old.get("item", ""),
                "category": old.get("category", "Cakes"),
                "flavour": old.get("flavour", ""),
                "quantity": old.get("quantity", 1),
                "unit_price": old.get("unit_price", 0),
                "amount_paid": old.get("amount_paid", 0),
                "pickup_date": old.get("pickup_date", ""),
                "pickup_slot": old.get("pickup_slot", "Afternoon"),
                "order_status": old.get("order_status", "Pending"),
                "priority": old.get("priority", "Standard"),
                "notes": old.get("notes", ""),
            }
            if validate_order(payload):
                continue
            order_id = str(old.get("order_id") or "")
            if not order_id or connection.execute("SELECT 1 FROM orders WHERE order_id=?", (order_id,)).fetchone():
                order_id = f"BR-{self._next_order_number(connection):04d}"
            created_at = str(old.get("created_at") or utc_now())
            record = normalise_order(payload, order_id, created_at=created_at)
            record["updated_at"] = str(old.get("updated_at") or record["created_at"])
            self._insert_order(connection, record)
            connection.execute(
                "INSERT INTO audit_log(order_id, action, summary, created_at) VALUES(?, 'MIGRATED', ?, ?)",
                (order_id, "Imported from the original JSON register", utc_now()),
            )

    @staticmethod
    def _next_order_number(connection: sqlite3.Connection) -> int:
        stored = connection.execute("SELECT value FROM app_meta WHERE key='next_order_number'").fetchone()
        saved_next = int(stored[0]) if stored else 1
        highest = connection.execute(
            """
            SELECT MAX(number) FROM (
                SELECT CAST(SUBSTR(order_id, 4) AS INTEGER) AS number
                FROM orders WHERE order_id GLOB 'BR-[0-9]*'
                UNION ALL
                SELECT CAST(SUBSTR(order_id, 4) AS INTEGER) AS number
                FROM audit_log WHERE order_id GLOB 'BR-[0-9]*'
            )
            """
        ).fetchone()[0]
        return max(saved_next, int(highest or 0) + 1)

    @staticmethod
    def _set_next_order_number(connection: sqlite3.Connection, number: int) -> None:
        connection.execute(
            "INSERT OR REPLACE INTO app_meta(key, value) VALUES('next_order_number', ?)",
            (str(max(1, int(number))),),
        )

    def _insert_order(self, connection: sqlite3.Connection, record: Mapping[str, Any]) -> None:
        columns = ", ".join(ORDER_COLUMNS)
        placeholders = ", ".join("?" for _ in ORDER_COLUMNS)
        values = [record.get(column, "") for column in ORDER_COLUMNS]
        connection.execute(f"INSERT INTO orders ({columns}) VALUES ({placeholders})", values)

    @staticmethod
    def _row_to_order(row: sqlite3.Row) -> dict[str, Any]:
        return {column: row[column] for column in ORDER_COLUMNS}

    def list_orders(self) -> list[dict[str, Any]]:
        with self._reader() as connection:
            rows = connection.execute(
                "SELECT * FROM orders ORDER BY CAST(SUBSTR(order_id, 4) AS INTEGER), order_id"
            ).fetchall()
            return [self._row_to_order(row) for row in rows]

    def get_order(self, order_id: str) -> dict[str, Any] | None:
        with self._reader() as connection:
            row = connection.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            return self._row_to_order(row) if row else None

    def create_order(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        error = validate_order(payload)
        if error:
            raise ValueError(error)
        with self._transaction() as connection:
            number = self._next_order_number(connection)
            order_id = f"BR-{number:04d}"
            record = normalise_order(payload, order_id)
            self._insert_order(connection, record)
            self._audit(connection, order_id, "CREATED", f"New order for {record['customer']} · {record['item']}")
            self._set_next_order_number(connection, number + 1)
            return record

    def update_order(self, order_id: str, changes: Mapping[str, Any]) -> dict[str, Any] | None:
        if not isinstance(changes, Mapping) or not changes:
            raise ValueError("Provide at least one field to update.")
        unknown = set(changes) - EDITABLE_FIELDS
        if unknown:
            raise ValueError("Unsupported update field(s): " + ", ".join(sorted(unknown)))
        with self._transaction() as connection:
            row = connection.execute("SELECT * FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not row:
                return None
            before = self._row_to_order(row)
            candidate = before.copy()
            candidate.update(changes)
            record = normalise_order(candidate, order_id, created_at=before["created_at"])
            assignments = ", ".join(f"{column}=?" for column in ORDER_COLUMNS if column != "order_id")
            values = [record[column] for column in ORDER_COLUMNS if column != "order_id"] + [order_id]
            connection.execute(f"UPDATE orders SET {assignments} WHERE order_id=?", values)
            changed = ", ".join(sorted(changes.keys()))
            self._audit(connection, order_id, "UPDATED", f"Updated fields: {changed}")
            return record

    def delete_order(self, order_id: str) -> bool:
        with self._transaction() as connection:
            row = connection.execute("SELECT customer, item FROM orders WHERE order_id=?", (order_id,)).fetchone()
            if not row:
                return False
            self._audit(connection, order_id, "DELETED", f"Deleted order for {row['customer']} · {row['item']}")
            connection.execute("DELETE FROM orders WHERE order_id=?", (order_id,))
            return True

    def bulk_create_orders(self, payloads: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
        prepared = list(payloads)
        errors = [validate_order(payload) for payload in prepared]
        if any(errors):
            first_error = next(error for error in errors if error)
            raise ValueError(first_error)
        created: list[dict[str, Any]] = []
        with self._transaction() as connection:
            number = self._next_order_number(connection) - 1
            for payload in prepared:
                number += 1
                order_id = f"BR-{number:04d}"
                record = normalise_order(payload, order_id)
                self._insert_order(connection, record)
                self._audit(connection, order_id, "IMPORTED", f"Imported order for {record['customer']} · {record['item']}")
                created.append(record)
            self._set_next_order_number(connection, number + 1)
        return created

    def clear_orders(self) -> int:
        with self._transaction() as connection:
            count = int(connection.execute("SELECT COUNT(*) FROM orders").fetchone()[0])
            if count:
                self._audit(connection, "*", "CLEARED", f"Cleared {count} order record(s)")
                connection.execute("DELETE FROM orders")
            return count

    @staticmethod
    def _audit(connection: sqlite3.Connection, order_id: str, action: str, summary: str) -> None:
        connection.execute(
            "INSERT INTO audit_log(order_id, action, summary, created_at) VALUES(?, ?, ?, ?)",
            (order_id, action, summary[:300], utc_now()),
        )

    def get_audit_log(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 200))
        with self._reader() as connection:
            rows = connection.execute(
                "SELECT id, order_id, action, summary, created_at FROM audit_log ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]

    def backup_payload(self) -> dict[str, Any]:
        return {
            "application": "Crumb & Co. Bakery Order Register",
            "schema_version": 2,
            "exported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "orders": self.list_orders(),
            "audit_log": self.get_audit_log(200),
        }

    def health(self) -> dict[str, Any]:
        with self._reader() as connection:
            result = connection.execute("PRAGMA quick_check").fetchone()[0]
            count = connection.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
        return {"database": "ok" if result == "ok" else "warning", "integrity": result, "orders": count}


DEFAULT_STORE = BakeryStore()
