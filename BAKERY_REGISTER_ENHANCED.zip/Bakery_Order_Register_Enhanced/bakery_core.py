"""Domain logic for the Crumb & Co. Bakery Order Register.

This module deliberately contains no web-framework or database code.  Keeping
validation, calculations and reporting here makes the rules reusable by the
Flask website, Streamlit interface, CLI and automated tests.
"""
from __future__ import annotations

import csv
import io
import random
import re
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Iterable, Mapping

STATUSES = ("Pending", "In Progress", "Completed", "Cancelled")
PAYMENT_STATUSES = ("Paid", "Partially Paid", "Unpaid")
CATEGORIES = ("Cakes", "Pastries", "Bread", "Cookies", "Desserts", "Other")
PICKUP_SLOTS = ("Morning", "Afternoon", "Evening")
PRIORITIES = ("Standard", "Urgent")

TEXT_LIMITS = {
    "customer": 80,
    "phone": 20,
    "item": 100,
    "flavour": 120,
    "notes": 500,
}
MONEY_QUANTUM = Decimal("0.01")
MAX_UNIT_PRICE = Decimal("10000000.00")
PHONE_RE = re.compile(r"^\+?[0-9][0-9\s()\-]{5,18}$")


def utc_now() -> str:
    """Return a timezone-aware, second-precision UTC timestamp."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _money(value: Any, label: str, max_value: Decimal = MAX_UNIT_PRICE * 500) -> Decimal:
    """Parse a finite non-negative monetary value to two decimal places."""
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, ValueError, TypeError, AttributeError):
        raise ValueError(f"{label} must be a valid number.") from None
    if not number.is_finite():
        raise ValueError(f"{label} must be a finite number.")
    if number < 0:
        raise ValueError(f"{label} cannot be negative.")
    if number > max_value:
        raise ValueError(f"{label} is above the supported limit.")
    try:
        return number.quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)
    except InvalidOperation:
        raise ValueError(f"{label} must be representable to two decimal places.") from None


def _as_float(value: Decimal) -> float:
    """Store money as a JSON/SQLite-friendly number after decimal rounding."""
    return float(value.quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP))


def _parse_quantity(value: Any) -> int:
    if isinstance(value, bool):
        raise ValueError("Quantity must be a whole number from 1 to 500.")
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, ValueError, TypeError, AttributeError):
        raise ValueError("Quantity must be a whole number from 1 to 500.") from None
    if not number.is_finite() or number != number.to_integral_value() or not 1 <= number <= 500:
        raise ValueError("Quantity must be a whole number from 1 to 500.")
    return int(number)


def validate_order(payload: Mapping[str, Any]) -> str | None:
    """Return a clear validation error, or ``None`` when an order is valid."""
    if not isinstance(payload, Mapping):
        return "Order details must be provided as an object."

    clean_text: dict[str, str] = {}
    for field, label in (("customer", "Customer name"), ("item", "Bakery item")):
        value = payload.get(field, "")
        if value is None or not str(value).strip():
            return f"{label} is required."

    for field, limit in TEXT_LIMITS.items():
        value = payload.get(field, "")
        if value is None:
            value = ""
        if not isinstance(value, (str, int, float)):
            return f"{field.replace('_', ' ').capitalize()} must be plain text."
        text = str(value).strip()
        if len(text) > limit:
            return f"{field.replace('_', ' ').capitalize()} must be {limit} characters or fewer."
        clean_text[field] = text

    phone = clean_text.get("phone", "")
    if phone and not PHONE_RE.fullmatch(phone):
        return "Phone number must contain 7–19 digits and may use +, spaces, brackets or hyphens."

    try:
        quantity = _parse_quantity(payload.get("quantity", 0))
        price = _money(payload.get("unit_price", ""), "Unit price", MAX_UNIT_PRICE)
        paid = _money(payload.get("amount_paid", 0), "Amount received", MAX_UNIT_PRICE * 500)
    except ValueError as exc:
        return str(exc) if str(exc) else "Enter a valid quantity, price and payment amount."
    try:
        date.fromisoformat(str(payload.get("pickup_date", "")).strip())
    except (ValueError, TypeError):
        return "Pickup date must use YYYY-MM-DD format."

    total = (price * quantity).quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)
    if paid > total:
        return "Amount received cannot exceed the total order value."

    status = str(payload.get("order_status", "Pending"))
    if status not in STATUSES:
        return "Choose a valid order status."
    category = str(payload.get("category", "Cakes"))
    if category not in CATEGORIES:
        return "Choose a valid bakery category."
    pickup_slot = str(payload.get("pickup_slot", "Afternoon"))
    if pickup_slot not in PICKUP_SLOTS:
        return "Choose a valid pickup slot."
    priority = str(payload.get("priority", "Standard"))
    if priority not in PRIORITIES:
        return "Choose a valid order priority."
    return None


def normalise_order(payload: Mapping[str, Any], order_id: str, *, created_at: str | None = None) -> dict[str, Any]:
    """Validate and return a complete, canonical order record."""
    error = validate_order(payload)
    if error:
        raise ValueError(error)

    quantity = _parse_quantity(payload["quantity"])
    price = _money(payload["unit_price"], "Unit price", MAX_UNIT_PRICE)
    paid = _money(payload.get("amount_paid", 0), "Amount received", MAX_UNIT_PRICE * 500)
    total = (price * quantity).quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)
    balance = (total - paid).quantize(MONEY_QUANTUM, rounding=ROUND_HALF_UP)
    payment_status = "Paid" if balance == 0 else ("Partially Paid" if paid > 0 else "Unpaid")

    return {
        "order_id": str(order_id),
        "customer": str(payload["customer"]).strip(),
        "phone": str(payload.get("phone", "") or "").strip(),
        "item": str(payload["item"]).strip(),
        "category": str(payload.get("category", "Cakes")),
        "flavour": str(payload.get("flavour", "") or "").strip(),
        "quantity": quantity,
        "unit_price": _as_float(price),
        "total_amount": _as_float(total),
        "amount_paid": _as_float(paid),
        "balance": _as_float(balance),
        "pickup_date": date.fromisoformat(str(payload["pickup_date"]).strip()).isoformat(),
        "pickup_slot": str(payload.get("pickup_slot", "Afternoon")),
        "payment_status": payment_status,
        "order_status": str(payload.get("order_status", "Pending")),
        "priority": str(payload.get("priority", "Standard")),
        "notes": str(payload.get("notes", "") or "").strip(),
        "created_at": created_at or utc_now(),
        "updated_at": utc_now(),
    }


def next_order_id(orders: Iterable[Mapping[str, Any]]) -> str:
    """Generate the next BR identifier, tolerating old or malformed IDs."""
    highest = 0
    for order in orders:
        raw = str(order.get("order_id", ""))
        match = re.fullmatch(r"BR-(\d+)", raw)
        if match:
            highest = max(highest, int(match.group(1)))
    return f"BR-{highest + 1:04d}"


def add_order(orders: list[dict[str, Any]], payload: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Pure helper retained for CLI, Streamlit and compatibility tests."""
    error = validate_order(payload)
    if error:
        raise ValueError(error)
    record = normalise_order(payload, next_order_id(orders))
    return [*orders, record]


EDITABLE_FIELDS = {
    "customer", "phone", "item", "category", "flavour", "quantity", "unit_price",
    "amount_paid", "pickup_date", "pickup_slot", "order_status", "priority", "notes",
}


def update_order(orders: list[dict[str, Any]], order_id: str, changes: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Return a changed order list after validating the complete updated order."""
    result: list[dict[str, Any]] = []
    found = False
    for existing in orders:
        if existing.get("order_id") != order_id:
            result.append(existing.copy())
            continue
        found = True
        candidate = existing.copy()
        candidate.update(changes)
        record = normalise_order(candidate, order_id, created_at=existing.get("created_at"))
        result.append(record)
    if not found:
        raise KeyError("Order not found")
    return result


def delete_order(orders: list[dict[str, Any]], order_id: str) -> list[dict[str, Any]]:
    return [order.copy() for order in orders if order.get("order_id") != order_id]


def search_orders(
    orders: Iterable[Mapping[str, Any]],
    query: str = "",
    payment: str = "All",
    status: str = "All",
    category: str = "All",
    priority: str = "All",
    pickup_from: str = "",
    pickup_to: str = "",
) -> list[dict[str, Any]]:
    q = str(query or "").casefold().strip()
    result = []
    for order in orders:
        if q:
            searchable = " ".join(str(value) for value in order.values()).casefold()
            if q not in searchable:
                continue
        if payment != "All" and order.get("payment_status") != payment:
            continue
        if status != "All" and order.get("order_status") != status:
            continue
        if category != "All" and order.get("category", "Cakes") != category:
            continue
        if priority != "All" and order.get("priority", "Standard") != priority:
            continue
        pickup = str(order.get("pickup_date", ""))
        if pickup_from and pickup < pickup_from:
            continue
        if pickup_to and pickup > pickup_to:
            continue
        result.append(dict(order))
    return result


def summarize(orders: Iterable[Mapping[str, Any]], *, today: date | None = None) -> dict[str, Any]:
    rows = list(orders)
    active = [o for o in rows if o.get("order_status") != "Cancelled"]
    cancelled = [o for o in rows if o.get("order_status") == "Cancelled"]

    def total(field: str, items: Iterable[Mapping[str, Any]]) -> Decimal:
        return sum((Decimal(str(o.get(field, 0) or 0)) for o in items), Decimal("0.00"))

    revenue = total("total_amount", active)
    paid = total("amount_paid", active)
    outstanding = total("balance", active)
    count = len(active)
    today = today or date.today()
    overdue = sum(
        1 for o in active
        if str(o.get("pickup_date", "")) < today.isoformat() and o.get("order_status") != "Completed"
    )
    return {
        "total": len(rows),
        "active_orders": count,
        "cancelled_orders": len(cancelled),
        "completed_orders": sum(o.get("order_status") == "Completed" for o in active),
        "overdue_orders": overdue,
        "urgent_orders": sum(o.get("priority", "Standard") == "Urgent" for o in active),
        "revenue": _as_float(revenue),
        "paid": _as_float(paid),
        "pending": _as_float(outstanding),
        "cancelled_value": _as_float(total("total_amount", cancelled)),
        "average": _as_float(revenue / count) if count else 0.0,
        "paid_orders": sum(o.get("payment_status") == "Paid" for o in active),
        "partial_orders": sum(o.get("payment_status") == "Partially Paid" for o in active),
        "unpaid_orders": sum(o.get("payment_status") == "Unpaid" for o in active),
    }


def build_analytics(orders: Iterable[Mapping[str, Any]], *, today: date | None = None) -> dict[str, Any]:
    """Prepare concise business and production analytics for the dashboard."""
    rows = [o for o in orders if o.get("order_status") != "Cancelled"]
    today = today or date.today()
    months: list[dict[str, Any]] = []
    month_cursor = date(today.year, today.month, 1)
    for offset in range(5, -1, -1):
        year = month_cursor.year
        month = month_cursor.month - offset
        while month <= 0:
            year -= 1
            month += 12
        start = date(year, month, 1)
        end = date(year + 1, 1, 1) if month == 12 else date(year, month + 1, 1)
        selected = [o for o in rows if start.isoformat() <= str(o.get("pickup_date", "")) < end.isoformat()]
        months.append({
            "month": start.strftime("%b %Y"),
            "orders": len(selected),
            "sales": round(sum(float(o.get("total_amount", 0)) for o in selected), 2),
        })

    item_totals: dict[str, dict[str, Any]] = {}
    category_totals: dict[str, float] = {}
    for order in rows:
        item_name = str(order.get("item", "Other"))
        item = item_totals.setdefault(item_name, {"item": item_name, "quantity": 0, "sales": 0.0})
        item["quantity"] += int(order.get("quantity", 0))
        item["sales"] += float(order.get("total_amount", 0))
        category = str(order.get("category", "Cakes"))
        category_totals[category] = category_totals.get(category, 0.0) + float(order.get("total_amount", 0))

    top_items = sorted(item_totals.values(), key=lambda x: (-x["quantity"], x["item"].casefold()))[:5]
    for item in top_items:
        item["sales"] = round(item["sales"], 2)

    pickup_days = []
    for offset in range(8):
        day = today + timedelta(days=offset)
        day_orders = [o for o in rows if o.get("pickup_date") == day.isoformat() and o.get("order_status") != "Completed"]
        pickup_days.append({
            "date": day.isoformat(),
            "label": day.strftime("%a, %d %b"),
            "orders": len(day_orders),
            "urgent": sum(o.get("priority", "Standard") == "Urgent" for o in day_orders),
            "items": sum(int(o.get("quantity", 0)) for o in day_orders),
        })

    return {
        "monthly": months,
        "top_items": top_items,
        "category_totals": {k: round(v, 2) for k, v in sorted(category_totals.items())},
        "pickup_load": pickup_days,
        "order_status": {
            status: sum(o.get("order_status") == status for o in rows)
            for status in STATUSES
        },
    }


def _csv_safe(value: Any) -> Any:
    """Guard spreadsheet exports against formula execution in text cells."""
    if isinstance(value, str) and value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


CSV_FIELDS = [
    "order_id", "customer", "phone", "item", "category", "flavour", "quantity",
    "unit_price", "total_amount", "amount_paid", "balance", "pickup_date",
    "pickup_slot", "payment_status", "order_status", "priority", "notes",
    "created_at", "updated_at",
]


def export_csv_bytes(orders: Iterable[Mapping[str, Any]]) -> bytes:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=CSV_FIELDS, extrasaction="ignore")
    writer.writeheader()
    for order in orders:
        row = {field: order.get(field, "") for field in CSV_FIELDS}
        for field in ("order_id", "customer", "phone", "item", "category", "flavour", "pickup_date", "pickup_slot", "payment_status", "order_status", "priority", "notes", "created_at", "updated_at"):
            row[field] = _csv_safe(str(row[field]) if row[field] is not None else "")
        writer.writerow(row)
    return stream.getvalue().encode("utf-8-sig")


def export_markdown(orders: Iterable[Mapping[str, Any]]) -> str:
    rows = list(orders)
    summary = summarize(rows)
    lines = [
        "# Bakery Order Register Summary", "",
        f"- Total orders: {summary['total']}",
        f"- Active orders: {summary['active_orders']}",
        f"- Cancelled orders: {summary['cancelled_orders']}",
        f"- Sales value (excluding cancellations): ₹{summary['revenue']:.2f}",
        f"- Amount received: ₹{summary['paid']:.2f}",
        f"- Outstanding balance: ₹{summary['pending']:.2f}",
        f"- Average active order value: ₹{summary['average']:.2f}", "", "## Orders", "",
        "| Order ID | Customer | Item | Pickup | Total | Paid | Balance | Payment | Status |",
        "|---|---|---|---|---:|---:|---:|---|---|",
    ]
    for order in rows:
        values = [
            order.get("order_id", ""), order.get("customer", ""), order.get("item", ""),
            order.get("pickup_date", ""), f"{float(order.get('total_amount', 0)):.2f}",
            f"{float(order.get('amount_paid', 0)):.2f}", f"{float(order.get('balance', 0)):.2f}",
            order.get("payment_status", ""), order.get("order_status", ""),
        ]
        safe = [str(v).replace("|", "\\|").replace("\n", " ") for v in values]
        lines.append("| " + " | ".join(safe) + " |")
    return "\n".join(lines)


def seed_demo_data(*, count: int = 40, seed: int = 87, today: date | None = None) -> list[dict[str, Any]]:
    """Generate repeatable demo orders without changing global random state."""
    rng = random.Random(seed)
    today = today or date.today()
    names = ["Ananya Rao", "Rahul Kumar", "Sravya Reddy", "Kiran Teja", "Meghana Das", "Arjun Patel", "Nisha Varma", "Sai Charan", "Pooja Singh", "Vikram Rao"]
    items = [
        ("Chocolate Truffle Cake", "Cakes"), ("Vanilla Birthday Cake", "Cakes"),
        ("Black Forest Cake", "Cakes"), ("Red Velvet Cake", "Cakes"),
        ("Butterscotch Cake", "Cakes"), ("Cupcake Box", "Pastries"),
        ("Pineapple Cake", "Cakes"), ("Brownie Box", "Desserts"),
        ("Butter Cookies", "Cookies"), ("Sourdough Loaf", "Bread"),
    ]
    flavours = ["Eggless", "1 kg, custom name", "Half kg", "Floral design", "Photo cake", "No nuts", "Classic"]
    result: list[dict[str, Any]] = []
    for index in range(count):
        quantity = rng.choice([1, 1, 1, 2, 3])
        price = rng.choice([250, 350, 450, 550, 650, 750, 850, 1000, 1250])
        total = quantity * price
        paid = rng.choice([0, 0, round(total / 2, 2), total])
        item, category = rng.choice(items)
        payload = {
            "customer": rng.choice(names), "phone": f"9{rng.randint(100000000, 999999999)}",
            "item": item, "category": category, "flavour": rng.choice(flavours),
            "quantity": quantity, "unit_price": price,
            "pickup_date": (today + timedelta(days=rng.randint(-3, 14))).isoformat(),
            "pickup_slot": rng.choice(PICKUP_SLOTS), "amount_paid": paid,
            "order_status": rng.choice(STATUSES), "priority": rng.choice(["Standard", "Standard", "Urgent"]),
            "notes": "Demo sample record",
        }
        result = add_order(result, payload)
    return result
