"""Optional Streamlit interface using the same SQLite database as the website."""
from __future__ import annotations

import csv
import io
import json
from datetime import date, timedelta

import pandas as pd
import streamlit as st

from bakery_core import (
    CATEGORIES,
    PICKUP_SLOTS,
    PRIORITIES,
    STATUSES,
    export_csv_bytes,
    export_markdown,
    seed_demo_data,
    summarize,
    validate_order,
)
from bakery_storage import DEFAULT_STORE

st.set_page_config(page_title="Bakery Order Register", page_icon="🧁", layout="wide")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap');
html, body, [class*="css"] {font-family:'DM Sans',sans-serif;}
.stApp {background:linear-gradient(135deg,#fffaf5 0%,#fff4ed 55%,#fdf0f3 100%);}
.block-container {padding-top:2rem;max-width:1400px;}
.hero {background:linear-gradient(120deg,#4b2638,#854b61);padding:28px 32px;border-radius:22px;color:white;margin-bottom:22px;box-shadow:0 12px 35px #5b2c3b20;}
.hero h1 {font-family:'Playfair Display',serif;font-size:2.4rem;margin:0;}
.hero p {color:#f5dce5;margin:.4rem 0 0;}
div[data-testid="stMetric"] {background:white;border:1px solid #f0dedb;padding:15px 18px;border-radius:16px;}
.stButton>button {border-radius:11px;font-weight:700;}
section[data-testid="stSidebar"] {background:#fff7f2;}
h2,h3 {color:#4b2638;}
</style>
""", unsafe_allow_html=True)

st.markdown("""<div class="hero"><h1>🧁 Bakery Order Register</h1>
<p>Manage customer orders, payments, production planning and business reports.</p></div>""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## 🧁 Bakery Desk")
    page = st.radio("NAVIGATION", ["Dashboard", "Add New Order", "Orders Register", "Search Orders", "Reports & Export", "Data Tools"])
    st.divider()
    st.caption("Shared SQLite database")
    st.caption("The Streamlit and Flask interfaces use the same saved orders.")

orders = DEFAULT_STORE.list_orders()
summary = summarize(orders)


def order_form_defaults(order=None):
    order = order or {}
    with st.form("order_editor", clear_on_submit=order is None):
        a, b = st.columns(2)
        customer = a.text_input("Customer name *", value=order.get("customer", ""), max_chars=80)
        phone = b.text_input("Phone number", value=order.get("phone", ""), max_chars=20)
        c, d = st.columns(2)
        item = c.text_input("Bakery item *", value=order.get("item", ""), max_chars=100)
        category = d.selectbox("Category", CATEGORIES, index=CATEGORIES.index(order.get("category", "Cakes")) if order.get("category", "Cakes") in CATEGORIES else 0)
        e, f = st.columns(2)
        flavour = e.text_input("Flavour / size / design", value=order.get("flavour", ""), max_chars=120)
        quantity = f.number_input("Quantity", min_value=1, max_value=500, value=int(order.get("quantity", 1)), step=1)
        g, h = st.columns(2)
        unit_price = g.number_input("Unit price (₹)", min_value=0.0, max_value=10_000_000.0, value=float(order.get("unit_price", 750.0)), step=50.0)
        amount_paid = h.number_input("Amount received (₹)", min_value=0.0, value=float(order.get("amount_paid", 0.0)), step=50.0)
        i, j, k = st.columns(3)
        pickup_date = i.date_input("Pickup date", value=date.fromisoformat(order["pickup_date"]) if order else date.today() + timedelta(days=1))
        pickup_slot = j.selectbox("Pickup slot", PICKUP_SLOTS, index=PICKUP_SLOTS.index(order.get("pickup_slot", "Afternoon")) if order.get("pickup_slot", "Afternoon") in PICKUP_SLOTS else 1)
        status = k.selectbox("Order status", STATUSES, index=STATUSES.index(order.get("order_status", "Pending")) if order.get("order_status", "Pending") in STATUSES else 0)
        priority = st.selectbox("Priority", PRIORITIES, index=PRIORITIES.index(order.get("priority", "Standard")) if order.get("priority", "Standard") in PRIORITIES else 0)
        notes = st.text_area("Special instructions", value=order.get("notes", ""), max_chars=500)
        st.info(f"Estimated total: ₹{quantity * unit_price:,.2f}")
        submitted = st.form_submit_button("Save changes" if order else "＋ Save order", use_container_width=True)
    if submitted:
        payload = {
            "customer": customer, "phone": phone, "item": item, "category": category,
            "flavour": flavour, "quantity": int(quantity), "unit_price": float(unit_price),
            "amount_paid": float(amount_paid), "pickup_date": pickup_date.isoformat(),
            "pickup_slot": pickup_slot, "order_status": status, "priority": priority,
            "notes": notes,
        }
        error = validate_order(payload)
        if error:
            st.error(error)
        else:
            try:
                if order:
                    DEFAULT_STORE.update_order(order["order_id"], payload)
                    st.success(f"{order['order_id']} updated successfully.")
                else:
                    record = DEFAULT_STORE.create_order(payload)
                    st.success(f"{record['order_id']} saved successfully.")
                st.rerun()
            except ValueError as exc:
                st.error(str(exc))


if page == "Dashboard":
    st.subheader("Business overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Active orders", summary["active_orders"])
    c2.metric("Sales value", f"₹{summary['revenue']:,.2f}")
    c3.metric("Amount received", f"₹{summary['paid']:,.2f}")
    c4.metric("Outstanding", f"₹{summary['pending']:,.2f}")
    left, right = st.columns([1.15, 1])
    with left:
        st.markdown("### Pickup workload · next 8 days")
        active = [o for o in orders if o["order_status"] not in ("Cancelled", "Completed")]
        start = date.today()
        days = []
        for offset in range(8):
            current = start + timedelta(days=offset)
            selected = [o for o in active if o["pickup_date"] == current.isoformat()]
            days.append({"Pickup date": current.strftime("%a %d %b"), "Orders": len(selected), "Items": sum(o["quantity"] for o in selected)})
        st.dataframe(pd.DataFrame(days), use_container_width=True, hide_index=True)
    with right:
        st.markdown("### Payment snapshot")
        st.metric("Paid orders", summary["paid_orders"])
        st.metric("Partially paid", summary["partial_orders"])
        st.metric("Unpaid", summary["unpaid_orders"])
        st.metric("Overdue pickups", summary["overdue_orders"])
        st.metric("Urgent orders", summary["urgent_orders"])
    if orders:
        st.markdown("### Sales by category")
        category_data = pd.DataFrame(orders)
        category_data = category_data[category_data["order_status"] != "Cancelled"].groupby("category")["total_amount"].sum()
        st.bar_chart(category_data)
    else:
        st.info("Add an order to start using the business dashboard.")

elif page == "Add New Order":
    st.subheader("Create a bakery order")
    order_form_defaults()

elif page == "Orders Register":
    st.subheader("All bakery orders")
    if not orders:
        st.info("No orders yet. Use Add New Order to create your first record.")
    else:
        display = pd.DataFrame(orders)
        columns = ["order_id", "customer", "phone", "item", "category", "quantity", "total_amount", "amount_paid", "balance", "pickup_date", "pickup_slot", "priority", "payment_status", "order_status"]
        st.dataframe(display[columns], use_container_width=True, hide_index=True)
        selected_id = st.selectbox("Choose order to edit or delete", [o["order_id"] for o in orders])
        selected = next(o for o in orders if o["order_id"] == selected_id)
        with st.expander("Edit selected order"):
            order_form_defaults(selected)
        if st.button("Delete selected order", type="secondary"):
            if DEFAULT_STORE.delete_order(selected_id):
                st.warning(f"{selected_id} deleted.")
                st.rerun()

elif page == "Search Orders":
    st.subheader("Find an order")
    query = st.text_input("Search by order ID, customer, phone, item or notes")
    x, y, z = st.columns(3)
    payment = x.selectbox("Payment", ["All", "Paid", "Partially Paid", "Unpaid"])
    status = y.selectbox("Order status", ["All", *STATUSES])
    category = z.selectbox("Category", ["All", *CATEGORIES])
    found = [o for o in orders if (not query or query.casefold() in " ".join(str(v) for v in o.values()).casefold())
             and (payment == "All" or o["payment_status"] == payment)
             and (status == "All" or o["order_status"] == status)
             and (category == "All" or o["category"] == category)]
    st.caption(f"{len(found)} matching order(s)")
    if found:
        st.dataframe(pd.DataFrame(found), use_container_width=True, hide_index=True)
    else:
        st.info("No matching records found.")

elif page == "Reports & Export":
    st.subheader("Reports and downloads")
    st.write(f"**Orders:** {summary['total']} · **Active sales:** ₹{summary['revenue']:,.2f} · **Outstanding:** ₹{summary['pending']:,.2f} · **Cancelled:** {summary['cancelled_orders']}")
    st.download_button("⬇ Download orders as CSV", data=export_csv_bytes(orders), file_name="bakery_orders_report.csv", mime="text/csv", use_container_width=True)
    st.download_button("⬇ Download summary as Markdown", data=export_markdown(orders).encode("utf-8"), file_name="bakery_summary.md", mime="text/markdown", use_container_width=True)
    st.download_button("⬇ Download full JSON backup", data=json.dumps(DEFAULT_STORE.backup_payload(), ensure_ascii=False, indent=2).encode("utf-8"), file_name="bakery_register_backup.json", mime="application/json", use_container_width=True)
    if orders:
        st.markdown("### Sales by order status")
        st.bar_chart(pd.DataFrame(orders).groupby("order_status")["total_amount"].sum())
    st.markdown("### Recent audit activity")
    audit = DEFAULT_STORE.get_audit_log(30)
    if audit:
        st.dataframe(pd.DataFrame(audit), use_container_width=True, hide_index=True)
    else:
        st.info("No activity has been recorded yet.")

elif page == "Data Tools":
    st.subheader("Data management")
    st.write("Import a CSV with customer, item, pickup_date, quantity and unit_price columns. Invalid rows are skipped and reported.")
    upload = st.file_uploader("Choose CSV file", type=["csv"])
    if upload and st.button("Import valid rows"):
        try:
            raw = upload.getvalue()
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError("CSV file must be 2 MB or smaller.")
            reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
            required = {"customer", "item", "pickup_date", "quantity", "unit_price"}
            headers = {str(field or "").strip().casefold() for field in (reader.fieldnames or [])}
            if not required.issubset(headers):
                raise ValueError("CSV is missing one or more required columns.")
            valid, errors = [], []
            for line, row in enumerate(reader, start=2):
                if not any(str(value or "").strip() for value in row.values()):
                    continue
                if len(valid) + len(errors) >= 1000:
                    raise ValueError("A maximum of 1,000 rows can be imported at one time.")
                record = {str(k).strip().casefold(): (v or "").strip() for k, v in row.items() if k}
                payload = {
                    "customer": record.get("customer", ""), "phone": record.get("phone", ""),
                    "item": record.get("item", ""), "category": record.get("category") or "Cakes",
                    "flavour": record.get("flavour", ""), "quantity": record.get("quantity") or "1",
                    "unit_price": record.get("unit_price") or "0", "pickup_date": record.get("pickup_date", ""),
                    "pickup_slot": record.get("pickup_slot") or "Afternoon", "amount_paid": record.get("amount_paid") or "0",
                    "order_status": record.get("order_status") or "Pending", "priority": record.get("priority") or "Standard",
                    "notes": record.get("notes", ""),
                }
                error = validate_order(payload)
                if error:
                    errors.append(f"Row {line}: {error}")
                else:
                    valid.append(payload)
            created = DEFAULT_STORE.bulk_create_orders(valid) if valid else []
            st.success(f"Imported {len(created)} valid row(s).")
            if errors:
                st.warning("\n".join(errors[:30]))
            st.rerun()
        except (UnicodeDecodeError, ValueError, csv.Error) as exc:
            st.error(f"Could not import CSV: {exc}")
    st.divider()
    st.markdown("### Demo data")
    st.write("Load 40 sample orders to demonstrate reporting and production planning. This replaces the current order register.")
    if st.button("Load 40 sample orders", type="secondary"):
        DEFAULT_STORE.clear_orders()
        DEFAULT_STORE.bulk_create_orders(seed_demo_data())
        st.success("40 sample orders loaded.")
        st.rerun()
    if st.button("Clear all order records", type="secondary"):
        count = DEFAULT_STORE.clear_orders()
        st.warning(f"Cleared {count} order record(s). The audit history is retained.")
        st.rerun()

st.divider()
st.caption("Crumb & Co. Bakery Order Register · Flask website and Streamlit interface share one SQLite database.")
