import io
import tempfile
import unittest
from pathlib import Path

from bakery_storage import BakeryStore

try:
    import web_app
except ModuleNotFoundError as error:
    if error.name in {"flask", "werkzeug"}:
        web_app = None
    else:
        raise


@unittest.skipIf(web_app is None, "Install Flask from requirements.txt to run API tests")
class BakeryApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.old_store = web_app.store
        web_app.store = BakeryStore(Path(self.temp.name) / "api.sqlite3", legacy_json_path=None)
        web_app.app.config["TESTING"] = True
        self.client = web_app.app.test_client()

    def tearDown(self):
        web_app.store = self.old_store
        self.temp.cleanup()

    def payload(self, **changes):
        data = {
            "customer": "Asha Rao", "phone": "9876543210", "item": "Chocolate Cake",
            "category": "Cakes", "flavour": "Eggless", "quantity": 2, "unit_price": 500,
            "pickup_date": "2026-12-01", "pickup_slot": "Afternoon", "amount_paid": 300,
            "order_status": "Pending", "priority": "Standard", "notes": "Birthday order",
        }
        data.update(changes)
        return data

    def test_home_health_and_security_headers(self):
        home = self.client.get("/")
        self.assertEqual(home.status_code, 200)
        self.assertIn(b"crumb & co.", home.data)
        health = self.client.get("/api/health")
        self.assertEqual(health.status_code, 200)
        self.assertEqual(health.get_json()["database"], "ok")
        self.assertEqual(home.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(home.headers["X-Frame-Options"], "DENY")
        self.assertIn("frame-ancestors 'none'", home.headers["Content-Security-Policy"])

    def test_config_endpoint(self):
        result = self.client.get("/api/config").get_json()
        self.assertIn("Cakes", result["categories"])
        self.assertIn("Urgent", result["priorities"])

    def test_create_list_summary_update_and_delete(self):
        response = self.client.post("/api/orders", json=self.payload())
        self.assertEqual(response.status_code, 201)
        order_id = response.get_json()["order"]["order_id"]
        self.assertEqual(self.client.get("/api/orders").get_json()["count"], 1)
        self.assertEqual(self.client.get(f"/api/orders/{order_id}").status_code, 200)
        summary = self.client.get("/api/summary").get_json()
        self.assertEqual(summary["revenue"], 1000)
        self.assertEqual(summary["paid"], 300)
        changed = self.client.patch(f"/api/orders/{order_id}", json={"amount_paid": 1000, "order_status": "Completed"})
        self.assertEqual(changed.status_code, 200)
        self.assertEqual(changed.get_json()["order"]["payment_status"], "Paid")
        self.assertEqual(self.client.delete(f"/api/orders/{order_id}").status_code, 200)
        self.assertEqual(self.client.get("/api/orders").get_json()["count"], 0)

    def test_rejects_invalid_json_and_fields(self):
        self.assertEqual(self.client.post("/api/orders", data="[]", content_type="application/json").status_code, 400)
        self.assertEqual(self.client.post("/api/orders", json=self.payload(quantity=0)).status_code, 400)
        created = self.client.post("/api/orders", json=self.payload()).get_json()["order"]
        self.assertEqual(self.client.patch(f"/api/orders/{created['order_id']}", json={"not_allowed": 1}).status_code, 400)
        self.assertEqual(self.client.patch("/api/orders/BR-9999", json={"amount_paid": 0}).status_code, 404)
        self.assertEqual(self.client.delete("/api/orders/BR-9999").status_code, 404)

    def test_search_filter_sort_and_pagination(self):
        self.client.post("/api/orders", json=self.payload(customer="Asha", priority="Urgent"))
        self.client.post("/api/orders", json=self.payload(customer="Ravi", category="Bread", item="Loaf"))
        result = self.client.get("/api/orders?priority=Urgent&limit=1").get_json()
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["orders"][0]["customer"], "Asha")
        category = self.client.get("/api/orders?category=Bread").get_json()
        self.assertEqual(category["count"], 1)
        bad_limit = self.client.get("/api/orders?limit=abc")
        self.assertEqual(bad_limit.status_code, 400)

    def test_analytics_and_audit_endpoints(self):
        self.client.post("/api/orders", json=self.payload())
        self.assertEqual(len(self.client.get("/api/analytics").get_json()["monthly"]), 6)
        events = self.client.get("/api/audit").get_json()["events"]
        self.assertEqual(events[0]["action"], "CREATED")

    def test_cross_origin_mutation_is_rejected(self):
        response = self.client.post("/api/orders", json=self.payload(), headers={"Origin": "https://example.com"})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.client.get("/api/orders").get_json()["count"], 0)

    def test_csv_import_skips_invalid_rows_and_keeps_valid_rows(self):
        csv_text = (
            "customer,phone,item,category,quantity,unit_price,pickup_date,pickup_slot,amount_paid,order_status,priority,notes\n"
            "Asha,9876543210,Cake,Cakes,1,500,2026-12-01,Afternoon,100,Pending,Standard,Good\n"
            "Bad,9876543210,Cake,Cakes,0,500,2026-12-01,Afternoon,0,Pending,Standard,Invalid quantity\n"
        )
        response = self.client.post("/api/import.csv", data={"file": (io.BytesIO(csv_text.encode()), "orders.csv")}, content_type="multipart/form-data")
        self.assertEqual(response.status_code, 200)
        payload = response.get_json()
        self.assertEqual(payload["imported"], 1)
        self.assertEqual(payload["rejected"], 1)
        self.assertIn("Row 3", payload["errors"][0])
        self.assertEqual(self.client.get("/api/orders").get_json()["count"], 1)

    def test_csv_import_requires_headers_and_extension(self):
        missing = self.client.post("/api/import.csv", data={"file": (io.BytesIO(b"name,item\nA,Cake"), "bad.csv")}, content_type="multipart/form-data")
        self.assertEqual(missing.status_code, 400)
        wrong_extension = self.client.post("/api/import.csv", data={"file": (io.BytesIO(b"a,b"), "file.txt")}, content_type="multipart/form-data")
        self.assertEqual(wrong_extension.status_code, 400)

    def test_csv_export_and_json_backup(self):
        self.client.post("/api/orders", json=self.payload(customer="=HYPERLINK(\"bad\")"))
        csv_response = self.client.get("/api/export.csv")
        self.assertEqual(csv_response.status_code, 200)
        self.assertIn(b"'=HYPERLINK", csv_response.data)
        backup = self.client.get("/api/backup.json")
        self.assertEqual(backup.status_code, 200)
        self.assertIn(b'"orders"', backup.data)
        self.assertIn(b'"audit_log"', backup.data)

    def test_csv_template_and_api_404(self):
        template = self.client.get("/api/template.csv")
        self.assertEqual(template.status_code, 200)
        self.assertIn(b"pickup_slot", template.data)
        self.assertEqual(self.client.get("/api/not-a-route").status_code, 404)


if __name__ == "__main__":
    unittest.main()
