import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from bakery_storage import BakeryStore


class BakeryStorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = BakeryStore(self.root / "bakery.sqlite3", legacy_json_path=None)

    def tearDown(self):
        self.temp.cleanup()

    def payload(self, **changes):
        data = {
            "customer": "Asha Rao", "phone": "9876543210", "item": "Chocolate Cake",
            "category": "Cakes", "flavour": "Eggless", "quantity": 2, "unit_price": 500,
            "pickup_date": "2026-12-01", "pickup_slot": "Afternoon", "amount_paid": 300,
            "order_status": "Pending", "priority": "Standard", "notes": "Birthday order",
        }
        data.update(changes)
        return data

    def test_create_update_delete_and_audit(self):
        created = self.store.create_order(self.payload())
        self.assertEqual(created["order_id"], "BR-0001")
        updated = self.store.update_order(created["order_id"], {"amount_paid": 1000, "order_status": "Completed"})
        self.assertEqual(updated["payment_status"], "Paid")
        self.assertEqual(self.store.get_order(created["order_id"])["order_status"], "Completed")
        self.assertTrue(self.store.delete_order(created["order_id"]))
        self.assertIsNone(self.store.get_order(created["order_id"]))
        actions = [event["action"] for event in self.store.get_audit_log()]
        self.assertEqual(actions[:3], ["DELETED", "UPDATED", "CREATED"])

    def test_invalid_update_is_not_persisted(self):
        created = self.store.create_order(self.payload())
        with self.assertRaises(ValueError):
            self.store.update_order(created["order_id"], {"amount_paid": 99999})
        self.assertEqual(self.store.get_order(created["order_id"])["amount_paid"], 300.0)

    def test_bulk_create_is_atomic_for_duplicate_id_scenarios(self):
        rows = self.store.bulk_create_orders([self.payload(), self.payload(customer="Ravi")])
        self.assertEqual([row["order_id"] for row in rows], ["BR-0001", "BR-0002"])
        self.assertEqual(len(self.store.list_orders()), 2)

    def test_concurrent_creates_receive_unique_ids(self):
        with ThreadPoolExecutor(max_workers=8) as executor:
            results = list(executor.map(lambda i: self.store.create_order(self.payload(customer=f"Customer {i}")), range(24)))
        ids = [record["order_id"] for record in results]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(len(self.store.list_orders()), 24)

    def test_order_ids_are_not_reused_after_delete_or_clear(self):
        first = self.store.create_order(self.payload())
        second = self.store.create_order(self.payload(customer="Ravi"))
        self.assertTrue(self.store.delete_order(second["order_id"]))
        third = self.store.create_order(self.payload(customer="Meera"))
        self.assertEqual(third["order_id"], "BR-0003")
        self.store.clear_orders()
        fourth = self.store.create_order(self.payload(customer="Kiran"))
        self.assertEqual(fourth["order_id"], "BR-0004")

    def test_clear_keeps_audit_history(self):
        self.store.bulk_create_orders([self.payload(), self.payload(customer="Ravi")])
        self.assertEqual(self.store.clear_orders(), 2)
        self.assertEqual(self.store.list_orders(), [])
        self.assertEqual(self.store.get_audit_log(1)[0]["action"], "CLEARED")

    def test_backup_payload_contains_orders_and_audit(self):
        self.store.create_order(self.payload())
        backup = self.store.backup_payload()
        self.assertEqual(backup["schema_version"], 2)
        self.assertEqual(len(backup["orders"]), 1)
        self.assertTrue(backup["audit_log"])
        self.assertEqual(self.store.health()["database"], "ok")

    def test_one_time_migration_from_legacy_json(self):
        legacy_path = self.root / "orders.json"
        legacy_path.write_text(json.dumps([{
            "order_id": "BR-0012", "customer": "Legacy Customer", "phone": "9876543210",
            "item": "Vanilla Cake", "flavour": "Classic", "quantity": 1, "unit_price": 450,
            "total_amount": 450, "amount_paid": 100, "balance": 350,
            "pickup_date": "2026-12-02", "payment_status": "Partially Paid",
            "order_status": "Pending", "notes": "Migrated", "created_at": "2026-11-20T10:00:00",
        }]), encoding="utf-8")
        migrated_store = BakeryStore(self.root / "migrated.sqlite3", legacy_json_path=legacy_path)
        data = migrated_store.list_orders()
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]["order_id"], "BR-0012")
        self.assertEqual(data[0]["category"], "Cakes")
        self.assertEqual(data[0]["balance"], 350.0)
        self.assertTrue(legacy_path.exists())
        self.assertEqual(migrated_store.get_audit_log(1)[0]["action"], "MIGRATED")


if __name__ == "__main__":
    unittest.main()
