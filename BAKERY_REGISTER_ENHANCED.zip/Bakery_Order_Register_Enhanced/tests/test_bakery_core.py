import csv
import io
import unittest
from datetime import date

from bakery_core import (
    add_order,
    build_analytics,
    delete_order,
    export_csv_bytes,
    export_markdown,
    next_order_id,
    search_orders,
    seed_demo_data,
    summarize,
    update_order,
    validate_order,
)


class BakeryCoreTests(unittest.TestCase):
    def payload(self, **changes):
        payload = {
            "customer": "Asha Rao",
            "phone": "+91 98765 43210",
            "item": "Chocolate Cake",
            "category": "Cakes",
            "flavour": "Eggless",
            "quantity": 2,
            "unit_price": 500,
            "pickup_date": date.today().isoformat(),
            "pickup_slot": "Afternoon",
            "amount_paid": 300,
            "order_status": "Pending",
            "priority": "Standard",
            "notes": "Birthday message",
        }
        payload.update(changes)
        return payload

    def test_add_calculates_money_and_payment_status(self):
        rows = add_order([], self.payload())
        self.assertEqual(rows[0]["order_id"], "BR-0001")
        self.assertEqual(rows[0]["total_amount"], 1000.0)
        self.assertEqual(rows[0]["balance"], 700.0)
        self.assertEqual(rows[0]["payment_status"], "Partially Paid")
        self.assertIn("updated_at", rows[0])

    def test_money_rounding_uses_decimal_half_up(self):
        rows = add_order([], self.payload(quantity=1, unit_price="12.345", amount_paid="0"))
        self.assertEqual(rows[0]["unit_price"], 12.35)
        self.assertEqual(rows[0]["total_amount"], 12.35)

    def test_rejects_blank_customer_and_item(self):
        self.assertIn("Customer name", validate_order(self.payload(customer="  ")))
        self.assertIn("Bakery item", validate_order(self.payload(item="")))

    def test_rejects_invalid_quantity(self):
        for quantity in (0, 501, 1.5, True, "not-a-number"):
            self.assertIn("Quantity", validate_order(self.payload(quantity=quantity)))

    def test_rejects_invalid_money(self):
        for price in (-1, "nan", "inf", "bad", 10_000_001):
            self.assertIsNotNone(validate_order(self.payload(unit_price=price)))
        self.assertIn("cannot exceed", validate_order(self.payload(amount_paid=1001)))

    def test_rejects_invalid_date_status_and_category(self):
        self.assertIn("pickup date", validate_order(self.payload(pickup_date="25/11/2026")).lower())
        self.assertIn("status", validate_order(self.payload(order_status="Baking")))
        self.assertIn("category", validate_order(self.payload(category="Unknown")))
        self.assertIn("pickup slot", validate_order(self.payload(pickup_slot="Night")))
        self.assertIn("priority", validate_order(self.payload(priority="Critical")))

    def test_phone_and_text_length_validation(self):
        self.assertIn("Phone", validate_order(self.payload(phone="abc123")))
        self.assertIn("80 characters", validate_order(self.payload(customer="x" * 81)))
        self.assertIn("500 characters", validate_order(self.payload(notes="x" * 501)))

    def test_search_filters_every_new_dimension(self):
        rows = add_order([], self.payload(notes="message for a birthday", priority="Urgent", category="Cakes"))
        self.assertEqual(len(search_orders(rows, "birthday")), 1)
        self.assertEqual(len(search_orders(rows, "", category="Cakes", priority="Urgent")), 1)
        self.assertEqual(len(search_orders(rows, "", category="Bread")), 0)

    def test_update_recalculates_total_and_revalidates(self):
        rows = add_order([], self.payload())
        order_id = rows[0]["order_id"]
        changed = update_order(rows, order_id, {"quantity": 3, "amount_paid": 1500})
        self.assertEqual(changed[0]["total_amount"], 1500.0)
        self.assertEqual(changed[0]["balance"], 0.0)
        self.assertEqual(changed[0]["payment_status"], "Paid")
        with self.assertRaises(ValueError):
            update_order(rows, order_id, {"amount_paid": 2000})
        with self.assertRaises(KeyError):
            update_order(rows, "BR-9999", {"notes": "no order"})

    def test_delete_and_id_generation_tolerate_legacy_ids(self):
        rows = add_order([], self.payload())
        rows = add_order(rows, self.payload(customer="Ravi"))
        self.assertEqual(next_order_id(rows), "BR-0003")
        self.assertEqual(next_order_id([{"order_id": "old-id"}]), "BR-0001")
        self.assertEqual(delete_order(rows, "BR-0001")[0]["order_id"], "BR-0002")

    def test_summary_excludes_cancelled_orders_from_sales(self):
        active = add_order([], self.payload())
        cancelled = add_order(active, self.payload(order_status="Cancelled", customer="Cancelled customer"))
        result = summarize(cancelled, today=date.today())
        self.assertEqual(result["total"], 2)
        self.assertEqual(result["active_orders"], 1)
        self.assertEqual(result["cancelled_orders"], 1)
        self.assertEqual(result["revenue"], 1000.0)
        self.assertEqual(result["pending"], 700.0)

    def test_analytics_contains_months_top_items_and_workload(self):
        rows = add_order([], self.payload())
        result = build_analytics(rows, today=date.today())
        self.assertEqual(len(result["monthly"]), 6)
        self.assertEqual(result["top_items"][0]["item"], "Chocolate Cake")
        self.assertEqual(len(result["pickup_load"]), 8)
        self.assertIn("Cakes", result["category_totals"])

    def test_csv_export_prevents_formula_injection(self):
        rows = add_order([], self.payload(customer="=HYPERLINK(\"https://bad\")"))
        raw = export_csv_bytes(rows).decode("utf-8-sig")
        self.assertIn("'=HYPERLINK", raw)
        self.assertIn("order_id", raw.splitlines()[0])

    def test_markdown_escapes_table_pipes(self):
        rows = add_order([], self.payload(customer="Asha | Rao"))
        report = export_markdown(rows)
        self.assertIn("Asha \\| Rao", report)

    def test_demo_data_is_deterministic_and_valid(self):
        first = seed_demo_data(count=10, seed=11, today=date(2026, 11, 25))
        second = seed_demo_data(count=10, seed=11, today=date(2026, 11, 25))
        self.assertEqual(first, second)
        self.assertEqual(len(first), 10)
        self.assertTrue(all(validate_order(order) is None for order in first))


if __name__ == "__main__":
    unittest.main()
