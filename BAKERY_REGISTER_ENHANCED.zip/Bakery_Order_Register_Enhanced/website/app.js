'use strict';

const $ = (id) => document.getElementById(id);
const money = (value) => '₹' + Number(value || 0).toLocaleString('en-IN', {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[character]));
const localISODate = (date = new Date()) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};
const parseLocalDate = (isoDate) => new Date(`${isoDate}T00:00:00`);
const formatDate = (isoDate, options = { day: 'numeric', month: 'short' }) => {
  if (!isoDate) return '—';
  const value = parseLocalDate(isoDate);
  return Number.isNaN(value.getTime()) ? esc(isoDate) : value.toLocaleDateString('en-IN', options);
};

let orders = [];
let analytics = {};
let summary = {};
let editingId = null;
let toastTimer = null;

function notify(message, isError = false) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3200);
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  let payload = {};
  try {
    payload = await response.json();
  } catch (_error) {
    payload = {};
  }
  if (!response.ok) {
    throw new Error(payload.error || `Request failed (${response.status}).`);
  }
  return payload;
}

function payClass(status) {
  return status === 'Paid' ? 'paid' : status === 'Unpaid' ? 'unpaid' : 'partial';
}
function statusClass(status) {
  return status === 'Completed' ? 'completed'
    : status === 'Pending' ? 'pending'
      : status === 'Cancelled' ? 'cancelled' : 'progress';
}
function badge(label, className) {
  return `<span class="pill ${className}">${esc(label)}</span>`;
}
function priorityBadge(priority) {
  return priority === 'Urgent'
    ? '<span class="pill urgent">Urgent</span>'
    : '<span class="pill standard">Standard</span>';
}

function go(page) {
  document.querySelectorAll('.page').forEach((section) => {
    section.classList.toggle('active', section.id === `page-${page}`);
  });
  document.querySelectorAll('.nav-link').forEach((button) => {
    button.classList.toggle('active', button.dataset.page === page);
  });
  if (page === 'new' && !editingId) resetForm();
  if (page === 'orders') renderOrders();
}

document.querySelectorAll('[data-page]').forEach((button) => {
  button.addEventListener('click', () => {
    if (button.dataset.page === 'new') editingId = null;
    go(button.dataset.page);
  });
});
document.querySelectorAll('[data-goto]').forEach((button) => {
  button.addEventListener('click', () => {
    if (button.dataset.goto === 'new') editingId = null;
    go(button.dataset.goto);
  });
});
$('quickAdd').addEventListener('click', () => {
  editingId = null;
  go('new');
});
$('today').textContent = new Date().toLocaleDateString('en-IN', {
  weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
});

async function refresh() {
  try {
    const [orderData, summaryData, analyticsData, auditData] = await Promise.all([
      api('/api/orders?limit=5000&sort=newest'),
      api('/api/summary'),
      api('/api/analytics'),
      api('/api/audit?limit=30'),
    ]);
    orders = orderData.orders || [];
    summary = summaryData;
    analytics = analyticsData;
    renderDashboard();
    renderOrders();
    renderPlanner();
    renderReports(auditData.events || []);
  } catch (error) {
    notify(error.message, true);
  }
}

function renderDashboard() {
  $('mOrders').textContent = summary.active_orders ?? 0;
  $('mRevenue').textContent = money(summary.revenue);
  $('mPaid').textContent = money(summary.paid);
  $('mBalance').textContent = money(summary.pending);
  $('collectionTotal').textContent = money(summary.paid);
  const collectionPercent = summary.revenue > 0
    ? Math.min(100, (summary.paid / summary.revenue) * 100) : 0;
  $('collectionBar').style.width = `${collectionPercent.toFixed(1)}%`;
  $('paidCount').textContent = summary.paid_orders ?? 0;
  $('partialCount').textContent = summary.partial_orders ?? 0;
  $('unpaidCount').textContent = summary.unpaid_orders ?? 0;

  const today = localISODate();
  const nextWeek = new Date();
  nextWeek.setDate(nextWeek.getDate() + 7);
  const end = localISODate(nextWeek);
  const upcoming = orders.filter((order) => order.pickup_date >= today
    && order.pickup_date <= end && !['Cancelled', 'Completed'].includes(order.order_status))
    .sort((a, b) => a.pickup_date.localeCompare(b.pickup_date)
      || a.pickup_slot.localeCompare(b.pickup_slot));
  $('pickupList').innerHTML = upcoming.length ? upcoming.slice(0, 7).map((order) => `
    <div class="pickup-item">
      <div class="pickup-date"><b>${parseLocalDate(order.pickup_date).getDate()}</b><small>${esc(formatDate(order.pickup_date, { month: 'short' }))}</small></div>
      <div class="pickup-info"><b>${esc(order.customer)} · ${esc(order.item)}</b><small>${esc(order.order_id)} · ${esc(order.pickup_slot)} · Qty ${order.quantity}</small></div>
      ${badge(order.payment_status, payClass(order.payment_status))}
    </div>`).join('') : '<div class="empty-state">No upcoming pickups in the next 7 days.</div>';

  const recent = [...orders].sort((a, b) => b.created_at.localeCompare(a.created_at)).slice(0, 6);
  $('recentRows').innerHTML = recent.length
    ? recent.map(renderRecentRow).join('')
    : '<tr><td colspan="6" class="empty-state">No orders yet. Create your first bakery order.</td></tr>';

  renderMonthlyChart();
  renderTopItems();
}

function renderRecentRow(order) {
  return `<tr>
    <td class="order-id">${esc(order.order_id)}</td>
    <td class="customer-name">${esc(order.customer)}<span class="subtext">${esc(order.phone || 'No phone')}</span></td>
    <td>${esc(order.item)}<span class="subtext">Qty ${order.quantity} · ${esc(order.category)}</span></td>
    <td>${esc(formatDate(order.pickup_date, { day: 'numeric', month: 'short', year: 'numeric' }))}</td>
    <td>${badge(order.payment_status, payClass(order.payment_status))}</td>
    <td>${badge(order.order_status, statusClass(order.order_status))}</td>
  </tr>`;
}

function renderMonthlyChart() {
  const months = analytics.monthly || [];
  const maxSales = Math.max(1, ...months.map((month) => Number(month.sales || 0)));
  $('monthlyChart').innerHTML = months.length ? months.map((month) => {
    const width = Math.max(month.sales > 0 ? 4 : 0, (Number(month.sales || 0) / maxSales) * 100);
    return `<div class="chart-row"><span>${esc(month.month)}</span><div class="chart-track"><div style="width:${width.toFixed(1)}%"></div></div><b>${money(month.sales)}</b></div>`;
  }).join('') : '<div class="empty-state">Add orders to see the sales trend.</div>';
}

function renderTopItems() {
  const items = analytics.top_items || [];
  $('topItems').innerHTML = items.length ? items.map((item, index) => `
    <div class="insight-row"><span class="rank">${index + 1}</span><div class="insight-label"><b>${esc(item.item)}</b><small>${Number(item.quantity)} unit(s) ordered</small></div><strong>${money(item.sales)}</strong></div>`).join('')
    : '<div class="empty-state">No item insights yet.</div>';
}

function renderOrders() {
  const query = ($('searchBox')?.value || '').trim().toLocaleLowerCase('en-IN');
  const payment = $('paymentFilter')?.value || 'All';
  const status = $('statusFilter')?.value || 'All';
  const category = $('categoryFilter')?.value || 'All';
  const priority = $('priorityFilter')?.value || 'All';
  const sort = $('sortFilter')?.value || 'newest';
  let filtered = orders.filter((order) => {
    const searchable = [order.order_id, order.customer, order.phone, order.item,
      order.category, order.flavour, order.notes].join(' ').toLocaleLowerCase('en-IN');
    return (!query || searchable.includes(query))
      && (payment === 'All' || order.payment_status === payment)
      && (status === 'All' || order.order_status === status)
      && (category === 'All' || order.category === category)
      && (priority === 'All' || order.priority === priority);
  });
  if (sort === 'pickup_asc') {
    filtered.sort((a, b) => a.pickup_date.localeCompare(b.pickup_date));
  } else if (sort === 'total_desc') {
    filtered.sort((a, b) => Number(b.total_amount) - Number(a.total_amount));
  } else if (sort === 'oldest') {
    filtered.sort((a, b) => a.created_at.localeCompare(b.created_at));
  } else {
    filtered.sort((a, b) => b.created_at.localeCompare(a.created_at));
  }

  $('orderRows').innerHTML = filtered.length ? filtered.map((order) => `
    <tr>
      <td class="order-id">${esc(order.order_id)}</td>
      <td class="customer-name">${esc(order.customer)}<span class="subtext">${esc(order.phone || 'No phone')}</span></td>
      <td>${esc(order.item)}<span class="subtext">${esc(order.category)} · ${esc(order.flavour)} · Qty ${order.quantity}</span></td>
      <td>${money(order.total_amount)}</td><td>${money(order.amount_paid)}</td><td>${money(order.balance)}</td>
      <td>${esc(formatDate(order.pickup_date))}<span class="subtext">${esc(order.pickup_slot)}</span></td>
      <td>${priorityBadge(order.priority)}</td>
      <td>${badge(order.payment_status, payClass(order.payment_status))}</td>
      <td>${badge(order.order_status, statusClass(order.order_status))}</td>
      <td><button class="text-btn edit-btn" data-id="${esc(order.order_id)}">Edit</button><button class="text-btn delete-btn" data-id="${esc(order.order_id)}">Delete</button></td>
    </tr>`).join('')
    : '<tr><td colspan="11" class="empty-state">No matching orders found.</td></tr>';
  $('resultCount').textContent = `Showing ${filtered.length} of ${orders.length} order(s)`;
}

['searchBox', 'paymentFilter', 'statusFilter', 'categoryFilter', 'priorityFilter', 'sortFilter'].forEach((id) => {
  $(id).addEventListener(id === 'searchBox' ? 'input' : 'change', renderOrders);
});

$('orderRows').addEventListener('click', async (event) => {
  const editButton = event.target.closest('.edit-btn');
  const deleteButton = event.target.closest('.delete-btn');
  if (editButton) openEdit(editButton.dataset.id);
  if (deleteButton) {
    const orderId = deleteButton.dataset.id;
    if (!window.confirm(`Delete ${orderId}? This action cannot be undone.`)) return;
    try {
      await api(`/api/orders/${encodeURIComponent(orderId)}`, { method: 'DELETE' });
      notify(`${orderId} deleted.`);
      await refresh();
    } catch (error) {
      notify(error.message, true);
    }
  }
});

function resetForm() {
  editingId = null;
  $('orderForm').reset();
  $('quantity').value = 1;
  $('price').value = 750;
  $('paid').value = 0;
  $('category').value = 'Cakes';
  $('pickupSlot').value = 'Afternoon';
  $('status').value = 'Pending';
  $('priority').value = 'Standard';
  $('pickup').min = localISODate();
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  $('pickup').value = localISODate(tomorrow);
  $('formHeading').textContent = 'Create a new order';
  $('saveButton').textContent = 'Save order →';
  updatePreview();
}

function updatePreview() {
  const quantity = Number($('quantity').value) || 0;
  const price = Number($('price').value) || 0;
  $('totalPreview').textContent = money(quantity * price);
}
['quantity', 'price'].forEach((id) => $(id).addEventListener('input', updatePreview));
$('cancelForm').addEventListener('click', () => {
  resetForm();
  go('dashboard');
});

function openEdit(orderId) {
  const order = orders.find((item) => item.order_id === orderId);
  if (!order) return;
  editingId = orderId;
  go('new');
  $('formHeading').textContent = `Update ${orderId}`;
  $('customer').value = order.customer;
  $('phone').value = order.phone;
  $('item').value = order.item;
  $('category').value = order.category || 'Cakes';
  $('flavour').value = order.flavour;
  $('quantity').value = order.quantity;
  $('price').value = order.unit_price;
  $('pickup').min = order.pickup_date < localISODate() ? order.pickup_date : localISODate();
  $('pickup').value = order.pickup_date;
  $('pickupSlot').value = order.pickup_slot || 'Afternoon';
  $('paid').value = order.amount_paid;
  $('status').value = order.order_status;
  $('priority').value = order.priority || 'Standard';
  $('notes').value = order.notes;
  $('saveButton').textContent = 'Save changes →';
  updatePreview();
}

$('orderForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const quantity = Number($('quantity').value);
  const price = Number($('price').value);
  const paid = Number($('paid').value);
  const total = quantity * price;
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 500
      || !Number.isFinite(price) || price < 0 || price > 10000000
      || !Number.isFinite(paid) || paid < 0 || paid > total) {
    notify('Check quantity, unit price and payment amount.', true);
    return;
  }
  const payload = {
    customer: $('customer').value.trim(),
    phone: $('phone').value.trim(),
    item: $('item').value.trim(),
    category: $('category').value,
    flavour: $('flavour').value.trim(),
    quantity,
    unit_price: price,
    pickup_date: $('pickup').value,
    pickup_slot: $('pickupSlot').value,
    amount_paid: paid,
    order_status: $('status').value,
    priority: $('priority').value,
    notes: $('notes').value.trim(),
  };
  if (!payload.customer || !payload.item || !payload.pickup_date) {
    notify('Customer, bakery item and pickup date are required.', true);
    return;
  }
  const saveButton = $('saveButton');
  saveButton.disabled = true;
  try {
    if (editingId) {
      await api(`/api/orders/${encodeURIComponent(editingId)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      notify('Order updated successfully.');
    } else {
      await api('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      notify('New order saved successfully.');
    }
    resetForm();
    await refresh();
    go('orders');
  } catch (error) {
    notify(error.message, true);
  } finally {
    saveButton.disabled = false;
  }
});

function renderPlanner() {
  const today = localISODate();
  const endDate = new Date();
  endDate.setDate(endDate.getDate() + 7);
  const end = localISODate(endDate);
  const active = orders.filter((order) => order.order_status !== 'Cancelled');
  const overdue = active.filter((order) => order.pickup_date < today && order.order_status !== 'Completed');
  const urgent = active.filter((order) => order.priority === 'Urgent' && order.order_status !== 'Completed');
  const upcoming = active.filter((order) => order.pickup_date >= today && order.pickup_date <= end && order.order_status !== 'Completed');
  $('overdueCount').textContent = overdue.length;
  $('urgentCount').textContent = urgent.length;
  $('upcomingItems').textContent = upcoming.reduce((sum, order) => sum + Number(order.quantity || 0), 0);
  $('dueThisWeek').textContent = active.filter((order) => order.pickup_date >= today && order.pickup_date <= end && order.order_status !== 'Completed').length;
  $('plannerRange').textContent = `${formatDate(today)} – ${formatDate(end)}`;

  const loads = analytics.pickup_load || [];
  const maxCount = Math.max(1, ...loads.map((day) => Number(day.orders || 0)));
  $('pickupLoad').innerHTML = loads.map((day) => `
    <div class="load-day">
      <div class="load-day-head"><b>${esc(day.label)}</b><span>${day.orders} order(s)</span></div>
      <div class="load-track"><div style="width:${((day.orders / maxCount) * 100).toFixed(1)}%"></div></div>
      <small>${day.items} item(s) to prepare · ${day.urgent} urgent</small>
    </div>`).join('');

  const attention = [...overdue, ...urgent.filter((order) => !overdue.includes(order))]
    .filter((order) => order.order_status !== 'Cancelled')
    .sort((a, b) => a.pickup_date.localeCompare(b.pickup_date));
  $('attentionRows').innerHTML = attention.length ? attention.map((order) => `
    <tr><td class="order-id">${esc(order.order_id)}</td><td>${esc(order.customer)}</td><td>${esc(order.item)}<span class="subtext">Qty ${order.quantity}</span></td>
    <td>${esc(formatDate(order.pickup_date, { day: 'numeric', month: 'short', year: 'numeric' }))}</td><td>${esc(order.pickup_slot)}</td><td>${priorityBadge(order.priority)}</td>
    <td>${badge(order.order_status, statusClass(order.order_status))}</td><td><button class="text-btn planner-edit" data-id="${esc(order.order_id)}">Edit</button></td></tr>`).join('')
    : '<tr><td colspan="8" class="empty-state">No overdue or urgent orders. Production is on track.</td></tr>';
}
$('attentionRows').addEventListener('click', (event) => {
  const button = event.target.closest('.planner-edit');
  if (button) openEdit(button.dataset.id);
});

function renderReports(events) {
  $('avgValue').textContent = money(summary.average);
  $('rPaid').textContent = summary.paid_orders ?? 0;
  $('rPartial').textContent = summary.partial_orders ?? 0;
  $('rUnpaid').textContent = summary.unpaid_orders ?? 0;
  $('auditRows').innerHTML = events.length ? events.map((event) => `
    <tr><td>${esc(new Date(event.created_at).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' }))}</td>
    <td class="order-id">${esc(event.order_id)}</td><td>${badge(event.action, 'activity')}</td><td>${esc(event.summary)}</td></tr>`).join('')
    : '<tr><td colspan="4" class="empty-state">No activity has been recorded yet.</td></tr>';
}

$('importForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const file = $('csvFile').files[0];
  if (!file) return;
  if (!file.name.toLowerCase().endsWith('.csv')) {
    $('importResult').textContent = 'Please choose a CSV file.';
    return;
  }
  const formData = new FormData();
  formData.append('file', file);
  $('importButton').disabled = true;
  $('importResult').textContent = 'Importing and validating rows…';
  try {
    const result = await api('/api/import.csv', { method: 'POST', body: formData });
    const errorPreview = (result.errors || []).slice(0, 8).join('\n');
    $('importResult').textContent = `${result.message} Rejected: ${result.rejected || 0}.${errorPreview ? `\n${errorPreview}` : ''}${result.truncated_errors ? `\n…and ${result.truncated_errors} more row error(s).` : ''}`;
    notify(result.message);
    $('csvFile').value = '';
    await refresh();
  } catch (error) {
    $('importResult').textContent = error.message;
    notify(error.message, true);
  } finally {
    $('importButton').disabled = false;
  }
});

resetForm();
refresh();
