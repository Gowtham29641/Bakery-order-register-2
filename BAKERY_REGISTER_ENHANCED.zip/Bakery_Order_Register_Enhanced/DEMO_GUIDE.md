# Bakery Order Register — Evaluation Demo Guide

Use this guide to demonstrate the upgraded project in a short review.

## 1. Live feature walkthrough

1. Run `RUN_PROJECT.bat` and open `http://127.0.0.1:5000`.
2. Create an order with a customer name, item, category, quantity, unit price, pickup date and time slot. Add a partial payment and mark the order as **Urgent**.
3. Show the dashboard: active order value, amount received, outstanding balance, payment breakdown, pickup schedule, sales trend and popular items.
4. Open **Orders register**, search by customer or item, filter by payment/status/category/priority and edit the order. Change its quantity or payment to demonstrate automatic total, balance and payment-status recalculation.
5. Open **Production planner** to show the pickup workload, urgent orders and overdue pickups.
6. Import `sample_import.csv`. Also try a CSV row with an invalid quantity to show row-level validation and error reporting.
7. Open **Reports & backups** and download the CSV register and JSON backup. Show the recent activity log.

## 2. How the implementation supports the evaluation rubric

| Evaluation area | Implementation evidence to show |
|---|---|
| Requirements fulfilment | Dashboard, order CRUD, filters, pickup scheduling, payment tracking, CSV import/export and JSON backup. |
| Code quality and best practices | Shared domain rules in `bakery_core.py`; persistence isolated in `bakery_storage.py`; Flask routes in `web_app.py`; frontend assets separated into HTML, CSS and JavaScript. |
| Functionality and reliability | Server-side validation, decimal-based money calculations, derived payment balances, SQLite transactions, input limits, error handling and automated tests. |
| System design and architecture | Flask REST API, indexed SQLite tables, write-ahead logging, repository layer, audit log and shared storage for the Flask, Streamlit and CLI interfaces. |
| Security and robustness | Parameterized SQL, bounded CSV uploads, strict field validation, formula-safe CSV export, cross-origin mutation checks and browser security headers. |
| Innovation and technical complexity | Production workload planner, urgent-order prioritization, six-month sales trend, popular-item analytics, category breakdown and traceable activity history. |

## 3. Test the project

Install the website dependency first, then run:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Install optional dependencies only when demonstrating the Streamlit interface:

```bash
python -m pip install -r requirements_optional.txt
streamlit run app.py
```

## 4. Important scope boundary

This is a local coursework/demo application. It does not include user accounts or role-based access, and should not be exposed directly to the public internet. A production deployment would need authentication, HTTPS, authorization, deployment hardening and operational monitoring.
