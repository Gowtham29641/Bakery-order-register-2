# Crumb & Co. — Bakery Order Register (Enhanced)

A local-first bakery order management system with a responsive Flask website, REST API, SQLite database, optional Streamlit interface and command-line interface. All three interfaces share the same database and business rules.

## Run the website on Windows

1. Extract the ZIP file.
2. Open the `Bakery_Order_Register_Enhanced` folder.
3. Double-click **`RUN_PROJECT.bat`**.
4. On the first run, the launcher creates `.venv` and installs Flask.
5. Open **http://127.0.0.1:5000** in your browser. Keep the terminal window open while using the website.

Requirements: Python 3.10 or newer. Internet is required only for the first dependency installation. During Python setup, enable **Add Python to PATH**.

## Run manually

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python web_app.py
```

Then visit `http://127.0.0.1:5000`.

## Optional interfaces

The Streamlit interface uses the same SQLite database:

```bash
python -m pip install -r requirements_optional.txt
streamlit run app.py
```

The command-line interface can be started with:

```bash
python cli.py
```

## Main features

- Dashboard with active order value, collections, outstanding balances and payment breakdown.
- Order management with customer details, product category, quantity, price, pickup date and time slot, priority, status and special instructions.
- Full order editing, deletion, search, filtering and sorting.
- Production planner with daily workload, overdue pickups and urgent orders.
- Business analytics: six-month pickup-month sales trend, popular items and category totals.
- CSV import with required-column checks, per-row validation, a 1,000-row cap and clear error reporting.
- CSV export with spreadsheet-formula injection protection, plus portable JSON backup export.
- SQLite persistence with transactions, indexes, write-ahead logging and an audit trail.
- Automatic one-time migration of existing `data/orders.json` records into the SQLite database.
- Automated domain, storage and API tests.

## Project structure

```text
Bakery_Order_Register_Enhanced/
├── web_app.py                 # Flask website server and REST API
├── bakery_core.py             # Shared validation, calculations and analytics
├── bakery_storage.py          # SQLite repository and audit trail
├── app.py                     # Optional Streamlit interface
├── cli.py                     # Optional command-line interface
├── website/
│   ├── index.html             # Responsive website structure
│   ├── styles.css             # Website styling
│   └── app.js                 # Frontend behaviour and API integration
├── data/
│   └── orders.json            # Legacy file (automatically migrated once)
├── tests/                     # Automated tests
├── sample_import.csv          # Example import file
├── requirements.txt           # Flask dependency
├── requirements_optional.txt  # Optional Streamlit dependencies
└── RUN_PROJECT.bat            # Windows launcher
```

The live database is created automatically at `data/bakery_register.db`. SQLite sidecar files are generated while the application is running. They are local data files and should not be committed to a public source repository.

## Test the project

Install the main dependency, then run:

```bash
python -m unittest discover -s tests -v
```

The test suite covers input validation, money calculations, ID generation, updates, persistence, audit history, legacy migration, concurrent order creation, CSV import/export, API responses and security headers.

## Data and security notes

- The website binds to `127.0.0.1` by default and is intended for local coursework demonstrations.
- The API includes strict input validation, bounded uploads, safe CSV export, database transactions and common browser security headers.
- This local demonstration does **not** include user login or role-based access. Do not expose it to the public internet or deploy it as a production business system without adding authentication, HTTPS, access control, monitoring and a production hosting setup.
- Use **Download full JSON backup** regularly and keep a copy outside the project folder.
- The first database start imports valid records from the original JSON file once. The original JSON file is not deleted.

## Evaluation note

The revision strengthens the requirements, code quality, functionality, architecture, security and technical-depth areas identified in the supplied evaluation breakdown. A 100% score cannot be guaranteed because the final score depends on the evaluator's rubric, live demonstration and any additional requirements. Run the tests and demonstrate each feature before submission.
