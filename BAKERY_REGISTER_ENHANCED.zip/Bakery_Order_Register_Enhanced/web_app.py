"""Flask website and REST API for Crumb & Co. Bakery Order Register."""
from __future__ import annotations

import csv
import io
import logging
import os
from pathlib import Path
from typing import Any

from flask import Flask, Response, jsonify, request, send_from_directory
from werkzeug.exceptions import RequestEntityTooLarge

from bakery_core import (
    CATEGORIES,
    PICKUP_SLOTS,
    PRIORITIES,
    STATUSES,
    build_analytics,
    export_csv_bytes,
    search_orders,
    summarize,
    validate_order,
)
from bakery_storage import DEFAULT_STORE, BakeryStore

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "website"
MAX_IMPORT_ROWS = 1000

app = Flask(__name__, static_folder=str(WEB_DIR), static_url_path="/static")
app.config.update(
    JSON_SORT_KEYS=False,
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)
app.logger.setLevel(logging.INFO)
store: BakeryStore = DEFAULT_STORE


def _json_object() -> dict[str, Any] | None:
    """Read a JSON object only; arrays, scalars and malformed bodies are rejected."""
    if not request.is_json:
        return None
    payload = request.get_json(silent=True)
    return payload if isinstance(payload, dict) else None


@app.after_request
def add_security_headers(response: Response) -> Response:
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; connect-src 'self'; "
        "base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'",
    )
    response.headers.setdefault("Cache-Control", "no-store" if request.path.startswith("/api/") else "no-cache")
    return response


@app.before_request
def protect_state_changing_api_requests():
    """Reject cross-site browser requests to local mutation endpoints."""
    if not request.path.startswith("/api/") or request.method not in {"POST", "PATCH", "PUT", "DELETE"}:
        return None
    origin = request.headers.get("Origin")
    expected_origin = request.host_url.rstrip("/")
    if origin and origin.rstrip("/") != expected_origin:
        return jsonify({"error": "Cross-origin requests are not allowed."}), 403
    if request.headers.get("Sec-Fetch-Site", "").casefold() == "cross-site":
        return jsonify({"error": "Cross-site requests are not allowed."}), 403
    return None


@app.errorhandler(RequestEntityTooLarge)
def request_too_large(_error):
    return jsonify({"error": "The uploaded file is too large. The maximum request size is 2 MB."}), 413


@app.errorhandler(404)
def not_found(_error):
    if request.path.startswith("/api/"):
        return jsonify({"error": "The requested API endpoint or record was not found."}), 404
    return "Page not found", 404


@app.errorhandler(500)
def internal_error(error):
    app.logger.exception("Unhandled request error: %s", error)
    if request.path.startswith("/api/"):
        return jsonify({"error": "An unexpected server error occurred. Please try again."}), 500
    return "An unexpected server error occurred.", 500


@app.get("/")
def home():
    return send_from_directory(WEB_DIR, "index.html")


@app.get("/api/health")
def health():
    try:
        health_data = store.health()
        status = 200 if health_data["database"] == "ok" else 503
        return jsonify({"status": "ok" if status == 200 else "warning", "service": "Bakery Order Register API", **health_data}), status
    except Exception:
        app.logger.exception("Health check failed")
        return jsonify({"status": "error", "error": "Database health check failed."}), 503


@app.get("/api/config")
def config():
    return jsonify({
        "statuses": STATUSES,
        "categories": CATEGORIES,
        "pickup_slots": PICKUP_SLOTS,
        "priorities": PRIORITIES,
        "max_import_rows": MAX_IMPORT_ROWS,
    })


@app.get("/api/orders")
def get_orders():
    rows = store.list_orders()
    found = search_orders(
        rows,
        query=request.args.get("q", ""),
        payment=request.args.get("payment", "All"),
        status=request.args.get("status", "All"),
        category=request.args.get("category", "All"),
        priority=request.args.get("priority", "All"),
        pickup_from=request.args.get("pickup_from", ""),
        pickup_to=request.args.get("pickup_to", ""),
    )
    sort_by = request.args.get("sort", "newest")
    if sort_by == "pickup_asc":
        found.sort(key=lambda order: (order["pickup_date"], order["pickup_slot"], order["order_id"]))
    elif sort_by == "total_desc":
        found.sort(key=lambda order: (-float(order["total_amount"]), order["order_id"]))
    elif sort_by == "oldest":
        found.sort(key=lambda order: (order["created_at"], order["order_id"]))
    else:
        found.sort(key=lambda order: (order["created_at"], order["order_id"]), reverse=True)

    try:
        limit = max(1, min(int(request.args.get("limit", 5000)), 5000))
        offset = max(0, int(request.args.get("offset", 0)))
    except ValueError:
        return jsonify({"error": "limit and offset must be whole numbers."}), 400
    return jsonify({
        "orders": found[offset:offset + limit],
        "count": len(found),
        "limit": limit,
        "offset": offset,
    })


@app.get("/api/orders/<order_id>")
def get_order(order_id: str):
    order = store.get_order(order_id)
    if not order:
        return jsonify({"error": "Order not found."}), 404
    return jsonify({"order": order})


@app.post("/api/orders")
def create_order():
    payload = _json_object()
    if payload is None:
        return jsonify({"error": "Send order details as a JSON object."}), 400
    error = validate_order(payload)
    if error:
        return jsonify({"error": error}), 400
    try:
        record = store.create_order(payload)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    app.logger.info("Created bakery order %s", record["order_id"])
    return jsonify({"message": "Order created successfully.", "order": record}), 201


@app.patch("/api/orders/<order_id>")
def edit_order(order_id: str):
    changes = _json_object()
    if changes is None:
        return jsonify({"error": "Send the updated fields as a JSON object."}), 400
    try:
        record = store.update_order(order_id, changes)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    if not record:
        return jsonify({"error": "Order not found."}), 404
    app.logger.info("Updated bakery order %s", order_id)
    return jsonify({"message": "Order updated successfully.", "order": record})


@app.delete("/api/orders/<order_id>")
def remove_order(order_id: str):
    if not store.delete_order(order_id):
        return jsonify({"error": "Order not found."}), 404
    app.logger.info("Deleted bakery order %s", order_id)
    return jsonify({"message": "Order deleted successfully."})


@app.get("/api/summary")
def summary():
    return jsonify(summarize(store.list_orders()))


@app.get("/api/analytics")
def analytics():
    return jsonify(build_analytics(store.list_orders()))


@app.get("/api/audit")
def audit():
    try:
        limit = int(request.args.get("limit", 40))
    except ValueError:
        return jsonify({"error": "limit must be a whole number."}), 400
    return jsonify({"events": store.get_audit_log(limit)})


@app.get("/api/export.csv")
def export_csv():
    content = export_csv_bytes(store.list_orders())
    return Response(
        content,
        mimetype="text/csv",
        headers={"Content-Disposition": 'attachment; filename="bakery_orders.csv"'},
    )


@app.get("/api/backup.json")
def export_backup():
    import json

    content = json.dumps(store.backup_payload(), ensure_ascii=False, indent=2).encode("utf-8")
    return Response(
        content,
        mimetype="application/json",
        headers={"Content-Disposition": 'attachment; filename="bakery_register_backup.json"'},
    )


@app.post("/api/import.csv")
def import_csv():
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify({"error": "Choose a CSV file to import."}), 400
    if Path(upload.filename).suffix.casefold() != ".csv":
        return jsonify({"error": "Upload a .csv file."}), 400
    try:
        text = upload.stream.read().decode("utf-8-sig")
    except UnicodeDecodeError:
        return jsonify({"error": "Please upload a UTF-8 CSV file."}), 400

    reader = csv.DictReader(io.StringIO(text, newline=""))
    if not reader.fieldnames:
        return jsonify({"error": "The CSV file is empty or has no header row."}), 400
    reader.fieldnames = [str(name or "").strip().casefold() for name in reader.fieldnames]
    required = {"customer", "item", "pickup_date", "quantity", "unit_price"}
    if not required.issubset(set(reader.fieldnames)):
        missing = ", ".join(sorted(required - set(reader.fieldnames)))
        return jsonify({"error": f"CSV is missing required column(s): {missing}."}), 400

    valid_rows: list[dict[str, Any]] = []
    errors: list[str] = []
    processed = 0
    for line_number, raw_row in enumerate(reader, start=2):
        if raw_row is None or not any(str(value or "").strip() for value in raw_row.values()):
            continue
        processed += 1
        if processed > MAX_IMPORT_ROWS:
            return jsonify({"error": f"A maximum of {MAX_IMPORT_ROWS} data rows can be imported at one time."}), 400
        row = {str(key).strip().casefold(): (value or "").strip() for key, value in raw_row.items() if key is not None}
        payload: dict[str, Any] = {
            "customer": row.get("customer", ""),
            "phone": row.get("phone", ""),
            "item": row.get("item", ""),
            "category": row.get("category") or "Cakes",
            "flavour": row.get("flavour", ""),
            "quantity": row.get("quantity") or "1",
            "unit_price": row.get("unit_price") or "0",
            "pickup_date": row.get("pickup_date", ""),
            "pickup_slot": row.get("pickup_slot") or "Afternoon",
            "amount_paid": row.get("amount_paid") or "0",
            "order_status": row.get("order_status") or "Pending",
            "priority": row.get("priority") or "Standard",
            "notes": row.get("notes", ""),
        }
        error = validate_order(payload)
        if error:
            errors.append(f"Row {line_number}: {error}")
        else:
            valid_rows.append(payload)

    try:
        created = store.bulk_create_orders(valid_rows) if valid_rows else []
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    app.logger.info("Imported %d bakery orders; %d row(s) rejected", len(created), len(errors))
    return jsonify({
        "message": f"Imported {len(created)} valid order(s).",
        "imported": len(created),
        "rejected": len(errors),
        "errors": errors[:100],
        "truncated_errors": max(0, len(errors) - 100),
    })


@app.get("/api/template.csv")
def csv_template():
    content = (
        "customer,phone,item,category,flavour,quantity,unit_price,pickup_date,"
        "pickup_slot,amount_paid,order_status,priority,notes\n"
        "Ananya Rao,9876543210,Chocolate Truffle Cake,Cakes,Eggless,1,750,2026-12-01,Afternoon,300,Pending,Standard,Happy birthday\n"
    )
    return Response(
        content,
        mimetype="text/csv",
        headers={"Content-Disposition": 'attachment; filename="bakery_import_template.csv"'},
    )


if __name__ == "__main__":
    # The local demo is intentionally bound to loopback; do not expose without auth.
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True)
