"""Optional command-line interface for the shared Bakery Order Register database."""
from __future__ import annotations

from bakery_core import export_markdown, summarize, validate_order
from bakery_storage import DEFAULT_STORE


def ask(prompt: str) -> str:
    return input(prompt).strip()


def main() -> None:
    while True:
        orders = DEFAULT_STORE.list_orders()
        print("\n=== CRUMB & CO. BAKERY ORDER REGISTER ===")
        print("1. Add order\n2. View orders\n3. Search orders\n4. Summary")
        print("5. Export Markdown report\n6. View recent activity\n0. Exit")
        choice = ask("Choose: ")
        if choice == "1":
            payload = {
                "customer": ask("Customer name: "),
                "phone": ask("Phone: "),
                "item": ask("Bakery item: "),
                "category": ask("Category (Cakes/Pastries/Bread/Cookies/Desserts/Other) [Cakes]: ") or "Cakes",
                "flavour": ask("Flavour/details: "),
                "quantity": ask("Quantity: "),
                "unit_price": ask("Unit price: "),
                "pickup_date": ask("Pickup date (YYYY-MM-DD): "),
                "pickup_slot": ask("Pickup slot (Morning/Afternoon/Evening) [Afternoon]: ") or "Afternoon",
                "amount_paid": ask("Amount received: ") or "0",
                "order_status": ask("Order status (Pending/In Progress/Completed/Cancelled) [Pending]: ") or "Pending",
                "priority": ask("Priority (Standard/Urgent) [Standard]: ") or "Standard",
                "notes": ask("Notes: "),
            }
            error = validate_order(payload)
            if error:
                print("Invalid:", error)
            else:
                record = DEFAULT_STORE.create_order(payload)
                print("Saved:", record["order_id"])
        elif choice == "2":
            for order in orders:
                print(order["order_id"], "|", order["customer"], "|", order["item"], "|", order["pickup_date"], "|", order["payment_status"], "|", order["order_status"])
            if not orders:
                print("No orders have been saved.")
        elif choice == "3":
            query = ask("Search keyword: ").casefold()
            found = [order for order in orders if query in " ".join(str(v) for v in order.values()).casefold()]
            for order in found:
                print(order["order_id"], "|", order["customer"], "|", order["item"], "|", order["pickup_date"])
            print(f"{len(found)} matching order(s).")
        elif choice == "4":
            print(summarize(orders))
        elif choice == "5":
            with open("bakery_summary.md", "w", encoding="utf-8") as report:
                report.write(export_markdown(orders))
            print("Saved bakery_summary.md")
        elif choice == "6":
            for event in DEFAULT_STORE.get_audit_log(20):
                print(event["created_at"], event["order_id"], event["action"], event["summary"])
        elif choice == "0":
            break
        else:
            print("Choose a valid menu option.")


if __name__ == "__main__":
    main()
