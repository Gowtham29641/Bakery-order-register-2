@echo off
setlocal
cd /d "%~dp0"
title Crumb ^& Co. Bakery Order Studio

echo.
echo  ================================================
echo       CRUMB ^& CO. - BAKERY ORDER STUDIO
echo  ================================================
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo Python was not found.
        echo Install Python 3.10 or newer from https://www.python.org/downloads/
        echo During installation, select "Add Python to PATH".
        pause
        exit /b 1
    )
    set "PYTHON=python"
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating the project environment...
    %PYTHON% -m venv .venv
    if errorlevel 1 goto failed
)

echo [2/3] Checking website dependencies...
".venv\Scripts\python.exe" -c "import flask" >nul 2>nul
if errorlevel 1 (
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 goto failed
)

echo [3/3] Starting the bakery website...
echo.
echo Website address: http://127.0.0.1:5000
echo Keep this window open while using the website.
echo Press Ctrl+C in this window to stop the website.
start "" cmd /c "timeout /t 2 /nobreak ^>nul ^& start http://127.0.0.1:5000"
".venv\Scripts\python.exe" web_app.py
goto end

:failed
echo.
echo Setup failed. Check your internet connection and Python installation.
pause
exit /b 1

:end
pause
endlocal
